# MASTER_QA_SUITE

[![CI](https://github.com/DiegoMendezT/MASTER_QA_SUITE/actions/workflows/ci.yml/badge.svg)](https://github.com/DiegoMendezT/MASTER_QA_SUITE/actions/workflows/ci.yml)
